Simple RestEasy HelloWorld example without using a web.xml file.
-----------------------------------------------------------------

Requirements
JDK 1.6 or higher
Maven 3.0 or higher
JBoss 1.7 or higher

The purpose of the example is show how to implement a web service
without using a web.xml file in any Servlet 3.x complaint container.