package de.infinit.incentive.helloworld;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import de.infinit.incentive.greeter.domain.UserDao;
import de.infinit.incentive.greeter.domain.User;

@Path("")
public class HelloWorld {
	@Inject  
    private UserDao userDao;

    @GET
    @Path("/helloworld/{id}")
    public Response getHelloWorld(@PathParam("id") String username) {

        User user = userDao.getForUsername(username);
        String value = null;
        
        if (user != null) {
            value = "Hello, " + user.getFirstName() + " " + user.getLastName() + "!";
        } else {
            value = "No such user exists! Use 'emuster' or 'jdoe' or 'gf' or 'gs'";
        }
        return Response.status(200).entity(value).build();
    }
}
